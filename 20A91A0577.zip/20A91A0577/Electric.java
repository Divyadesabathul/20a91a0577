import java.util.*;
class Electric
{
  private int pro_id;
  private String pro_name;
  private String pro_details;
  private float pro_count;
  
  public Electric(int pro_id,String pro_name,String pro_details,float pro_count)
  {
     this.pro_id=pro_id;
     this.pro_name=pro_name;
     this.pro_count=pro_count;
     this.pro_details=pro_details;
  }
  public int getPro_id()
  {
     return pro_id;
  }
  public String getPro_name()
   {
     return pro_name;
   }
  public float getPro_count()
   {
     return pro_count;
    }
   public String  getPro_details()
   {
      return pro_details;
   }
  public void setPro_count(float count)
   {
      this.pro_count+=count;
   }
 }

class Product
{
   final int no_pro=10;
   Electric pro[]=new Electric[no_pro];
   int i=0;
   public void addpro(Electric e)
    {
       pro[i]=e;
       i++;
    }     
   public void viewAllproductDetails()
   {
       System.out.println("pro No \t pro Name \t\t pro details \t pro count");
       for(int j=0;j<i;j++)
       {
          System.out.println(pro[j].getpro_id()+"\t\t"+pro[j].getPro_name()+"\t\t"+pro[j].getPro_details()+"\t"+pro[j].getpro_count());

       }
   }
   public void Add(int pro_id,float pro_count)
    {
       for(int j=0;j<i;j++)
        {
           if(pro[j].getPro_id()==pro_id)
                {
                     pro[j].setPro_count(pro[j].getPro_count()+pro_count);
                     return;
                 }
        }
        System.out.println("Invalid product Number");
    }
    public void delete(int pro_id)
    {
       for(int j=0;j<i;j++)
        {
           if(pro[j].getPro_id()==pro_id)
                {
                     pro[j].setPro_count(0);
                     return;
                 }
        }
        System.out.println("Invalid product Number");
    }
    public void printdetail(int pro_id)
    {
       for(int j=0;j<i;j++)
        {
           if(pro[j].getPro_id()==pro_id)
                {
                     System.out.println("Pro No \t Pro Name \t\t Pro details \t pro count");
                     System.out.println(pro[j].getPro_id()+"\t\t"+pro[j].getPro_name()+"\t\t"+pro[j].getPro_details()+"\t"+pro[j].getPro_count());
                     return;
                 }
        }
        System.out.println("Invalid product Number");
    }
}
class Store
{
  public static void main(String args[])
   {
        Store c=new Store();
        Store a;
        int id,ch;
        String name,details;
        float cnt;
        Scanner sc=new Scanner(System.in);
        while(true)
        {
           System.out.println("1.Add Items \n 2.View Items \n 3.item count \n 4.item details \n 5.Delete item \n 6.Exit");
           ch=sc.nextInt();
           switch(ch)
           {
             case 1:
                     id=sc.nextInt();
                     sc.nextLine();
                     name=sc.nextLine();
                     cnt=sc.nextFloat();
                     sc.nextLine();
                     details=sc.nextLine();
                     a=new Store(id,name,details,cnt);
                     c.addItem(a);
                     break;
             case 2:
                     c.viewAllproductDetails();
                      break;
             case 3:
                     id=sc.nextInt();
                     cnt=sc.nextFloat();
		               c.Add(id,cnt);
                     break;
             case 4:
                     id=sc.nextInt();
                     c.printdetail(id);
                     break;
             case 5:
                     id=sc.nextInt();
                     sc.nextLine();
                     c.delete(id);
                     break;
             case 6:
                     System.exit(0);
           }
         }

   }
}
