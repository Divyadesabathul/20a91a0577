import java.util.*;
class Invent
{
    static Scanner sc=new Scanner(System.in);
    static void Insert(ArrayList<String> productlist,ArrayList<ArrayList<String>> productdetails,ArrayList<Integer> productcount)
    {
        System.out.println("Enter product name");
        String pname=sc.next();
        
        System.out.println("Enter product quantity");
        int pquan=sc.nextInt();
        System.out.println("Enter Specifications");
        sc.nextLine();
        String speci=sc.nextLine();
        System.out.println("Enter Cost");
        String cos=sc.next();
        productlist.add(pname);
        ArrayList<String> a=new ArrayList<>();
        a.add(speci);
        a.add(cos);
        a.add(Integer.toString(pquan));
        productdetails.add(a);
        productcount.add(pquan);
    }
    static void viewProducts(ArrayList<String> productlist,ArrayList<ArrayList<String>> productdetails,ArrayList<Integer> productcount)
    {
        for(int i=0;i<productlist.size();i++)
        {
            System.out.print(productlist.get(i)+"  ");
            String d="";
            for(int j=0;j<productdetails.get(i).size();j++)
            d+=productdetails.get(i).get(j)+" ";
            System.out.print(d);
            System.out.println("\n");
        }
    }
    static void productlist(ArrayList<String> productlist,ArrayList<Integer> productcount)
    {
        System.out.println("Enter productname to get count");
        String name=sc.next();
        int i=productlist.indexOf(name);
        System.out.println(productlist.get(i)+" "+productcount.get(i));
    }
    static void editproduct(ArrayList<String> productlist,ArrayList<ArrayList<String>> productdetails,ArrayList<Integer> productcount)
    {
        System.out.println("Enter productname to edit details");
        String e=sc.next();
        int t=productlist.indexOf(e);
        System.out.println("Enter product quantity");
        int pquan=sc.nextInt();
        System.out.println("Enter Specifications");
        sc.nextLine();
        String specify=sc.nextLine();
        System.out.println("Enter Cost");
        String cos=sc.next();
        ArrayList<String> a=new ArrayList<>();
        a.add(specify);
        a.add(cos);
        a.add(Integer.toString(pquan));
        productdetails.set(t, a);
        productcount.set(t,pquan);
    }
    static void productcount(ArrayList<String> productlist,ArrayList<Integer> productcount)
    {
        System.out.println("Enter item name to get count");
        String pname=sc.next();
        int i=productlist.indexOf(pname);
        System.out.println(productlist.get(i)+"    "+productcount.get(i));
    }
    static void uproductdetailsateinventory(ArrayList<String> productlist,ArrayList<ArrayList<String>> productdetails,ArrayList<Integer> productcount)
    {
        System.out.println("Enter 1 to update and 2 to delete item quantity");
        int choice=sc.nextInt();
        if(choice==1)
        {
            System.out.println("Enter item name");
            String pname=sc.next();
            System.out.println("Enter no of items to add");
            int n=sc.nextInt();
            int i=productlist.indexOf(pname);
            productcount.set(i,productcount.get(i)+n);
            int m=productcount.get(i);
            productdetails.get(i).set(2,Integer.toString(m));
        }
        else
        {
            System.out.println("Enter item name");
            String pname=sc.next();
            System.out.println("Enter no of items to add");
            int n=sc.nextInt();
            int i=productlist.indexOf(pname);
            productcount.set(i,productcount.get(i)-n);
            int m=productcount.get(i);
            productdetails.get(i).set(2,Integer.toString(m));
        }
    }
    public static void main(String[] args) {
        ArrayList<String> productlist=new ArrayList<>();
        ArrayList<ArrayList<String>> productdetails=new ArrayList<>();
        ArrayList<Integer> productcount=new ArrayList<>();
        System.out.println("Enter Number of items to be added");
        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            Insert(productlist,productdetails,productcount);
        }
        //viewProducts(productlist, productdetails, productcount);
        //productcount(productlist,productcount);
        
        int d=1;

        while(d==1)
        {
            System.out.print("select value to perform specific operation");
            System.out.print("1.print data");
            System.out.print("2.Add products");
            System.out.print("3.count of products");
            System.out.print("4.update details");
            System.out.print("5.to exit");
            int x=sc.nextInt();
            switch(x)
            {
                case 1:
                    viewProducts(productlist, productdetails, productcount);
                    break;
                case 2:
                    Insert(productlist,productdetails,productcount);
                    break;
                case 3:
                    productcount(productlist,productcount);
                    break;
                case 4:
                    uproductdetailsateinventory(productlist,productdetails,productcount);
                    break;
                default:
                    d=0;
                    break;
                    
            }

        }

    } 
}
