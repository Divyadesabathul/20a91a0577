import java.util.*;
import java.util.Collections;
class uni
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        HashMap<Integer,Integer>hm=new HashMap<>();
        int p;
        p=sc.nextInt();
        for(int i=0;i<p;i++)
        {
            int q=sc.nextInt();
            if(hm.containsKey(q))
            {
                hm.put(q,hm.get(q)+1);
            }
            else{
                hm.put(q,1);
            }
        }
        for(Map.Entry<Integer,Integer>ef:hm.entrySet())
        {
            if(ef.getValue()==1)
            {
                System.out.print(ef.getKey()+" ");
            }
        }
    }
}