import java.util.*;
import java.util.Collections;
class Miss
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int p;
        p=sc.nextInt();
        ArrayList<Integer>al=new ArrayList<>();
        for(int i=0;i<p;i++)
        {
            al.add(sc.nextInt());
        }
        for(int i=1;i<p;i++)
        {
            if(al.contains(i)==false)
            {
                al.add(i);
            }
        }
        System.out.println(al);

    }
}