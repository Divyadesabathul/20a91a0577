import java.util.*;
class Cumulativesum
{
public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the size of array");
    int n=sc.nextInt();
    System.out.println("Enter the Elements into Array:");
    int arr[]=new int[n];
    for(int i=0;i<n;i++)
    arr[i]=sc.nextInt();
    System.out.print(arr[0]+" ");
    for(int i=1;i<n;i++)
    {
        arr[i]=arr[i]+arr[i-1];
        System.out.print(arr[i]+" ");
    }
    // int pre[]=new int[n];
    // pre[0]=a[0];
    // for(int i=1;i<n;i++)
    // pre[i]=pre[i-1]+a[i];
    // System.out.println("Cumulative Sum Array:");
    // for(int i=0;i<n;i++)
    // System.out.print(pre[i]+" ");
     sc.close();
}
}